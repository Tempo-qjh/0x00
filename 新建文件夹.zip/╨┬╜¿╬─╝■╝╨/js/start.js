document.addEventListener('DOMContentLoaded', function () {
    const container = document.querySelector('.container');
    const startButton = document.getElementById('startButton');

    container.classList.add('show');

    const swiper = new Swiper('.swiper-container', {
        loop: true, // 循环模式
        effect: 'fade', // 设置为淡入淡出效果
        fadeEffect: {
            crossFade: true // 设置交叉淡入淡出
        },
        autoplay: {
            delay: 4000, // 
            disableOnInteraction: false, // 允许用户交互后继续自动播放
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true, // 点击分页指示器
        },
    
        on: {
            slideChangeTransitionStart: function () {
                const activeSlide = this.slides[this.activeIndex];
                const img = activeSlide.querySelector('img');
                const text = activeSlide.querySelector('.slide-text');
                const allText = document.querySelectorAll('.slide-text');
    
                // 重置图像动画
                if (img) {
                    img.style.animation = 'none'; 
                    img.offsetHeight; // 触发重排
                    img.style.animation = 'scaleOut 4s ease-in forwards'; 
                }
    
                // 隐藏所有文本
                allText.forEach(t => {
                    t.style.opacity = '0'; 
                    t.style.transition = 'opacity 0.5s ease';
                });
    
                // 显示当前活动的文本
                if (text) {
                    text.style.opacity = '1';
                    text.style.transition = 'opacity 0.5s ease'; 
                }
            }
        }
    });
    
    // 开始按钮点击事件
startButton.addEventListener('click', function () {
        window.location.href = 'index.html'; // 跳转到首页
});
})