let currentSection = 0;
const sections = document.querySelector('.screen');
const totalSectionss = sections.length;

// 获取图片容器

window.addEventListener('wheel', (event) => {
    if (event.deltaY > 0){
        if(currentSection < totalSectionss - 1){
            currentSection++;
            // 检测滚轮向下，之后容器加一
        }
    } else {
        if(currentSection > 0){
            currentSection--;
            //检测滚轮向上
        }
    }

    sections[currentSection].scrollIntoView({ behavior: 'smooth'});
    // 平滑的切换图片
})


const colors = [
    { r: 59, g: 46, b: 46 },  // screen1
    { r: 78, g: 77, b: 76 },  // screen2
    { r: 122, g: 138, b: 121 }, // screen3
    { r: 168, g: 230, b: 163 }, // screen4
    { r: 179, g: 232, b: 179 }, // screen5
    { r: 208, g: 232, b: 208 },

];


document.addEventListener("scroll", () => {
    const scrollTop = window.scrollY;
    const documentHeight = document.documentElement.scrollHeight - window.innerHeight;
    const scrollPercentage = scrollTop / documentHeight;

    const screenCount = colors.length;
    const currentScreenIndex = Math.min(Math.floor(scrollPercentage * screenCount), screenCount - 1);

    const startColor = colors[currentScreenIndex];
    const endColor = colors[Math.min(currentScreenIndex + 1, screenCount - 1)];

    const localScrollPercentage = (scrollPercentage * screenCount) % 1;
    const r = Math.round(startColor.r + (endColor.r - startColor.r) * localScrollPercentage);
    const g = Math.round(startColor.g + (endColor.g - startColor.g) * localScrollPercentage);
    const b = Math.round(startColor.b + (endColor.b - startColor.b) * localScrollPercentage);

    const backgroundColor = `rgb(${r}, ${g}, ${b})`;
    document.body.style.backgroundColor = backgroundColor;

    const buttons = document.querySelectorAll(".banner-button");
    buttons.forEach(button => {
        button.style.backgroundColor = backgroundColor;
    });
});